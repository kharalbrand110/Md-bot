# 🤖 WhatsApp Social Media Downloader Bot

A web-based WhatsApp bot for downloading videos from social media platforms.

## ✨ Features
- 📱 WhatsApp integration via web interface
- 🎬 Download from YouTube, Instagram, Facebook, TikTok, Twitter
- 🔗 Easy pairing system
- 📊 Admin dashboard
- 🌐 Web-based control panel

## 🚀 Quick Start

### Prerequisites
- Node.js 18 or higher
- Python 3.7+ (for yt-dlp)
- WhatsApp account (spare number)

### Installation
```bash
# Clone repository
git clone https://github.com/yourusername/whatsapp-bot-web.git
cd whatsapp-bot-web

# Install dependencies
npm install

# Install yt-dlp (for video downloads)
pip3 install yt-dlp

# Start the bot
npm start